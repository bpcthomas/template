# Cloudformation

Todo los objetos para construir la infraestructura como codigo.
Cloudformation / Ansiable

Definidos por tipos: YAML / JSON

Preferible: YAML
