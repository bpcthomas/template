# Train
Toda las librerias y la ejecucion del entrenamiento del modelo

y como ejecutar el entrenamiento del modelo analitco
