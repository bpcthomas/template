# Labdas
Los lambdas son funciones Serverless que sera usdas en la orquetación de procesos

